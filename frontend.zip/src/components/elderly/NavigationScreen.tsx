// ============================================================
// NavigationScreen — 지도 풀스크린 + 오버레이 안내 (C안)
// ============================================================
// 학술 근거: Scientific Reports 2025.12 (Nature, 50-69세 N=40)
// - 지도 유지 (익숙한 패러다임) + 음성 안내 (인지 부담 감소)
// - 카메라 follow → 시각적 위치 파악 부담 감소
// - 경로 이탈 3초 지속 시 자동 재탐색
// - 진행방향 화살표 마커 (heading 기반)

import React, { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  StyleSheet,
  Text,
  TouchableOpacity,
  StatusBar,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Location from "expo-location";
import {
  speak as ttsSpeak,
  stop as ttsStop,
} from "../../services/tutorialSpeechService";
import {
  NaverMapView,
  NaverMapPolylineOverlay,
  NaverMapMarkerOverlay,
} from "@mj-studio/react-native-naver-map";

import type {
  TmapResponse,
  NavigationCard,
  NavigationRoute,
} from "../../types/navigation";
import { parseTmapResponse } from "../../utils/tmapCardParser";
import {
  haversine,
  distanceToPath,
  passedCoordsUpTo,
  formatDistance,
  formatDuration,
} from "../../utils/haversine";
import NavigationCardUI from "./NavigationCardUI";
import { shouldShowMarker } from "../../utils/markerFilter";
import { Colors, Spacing, Radius, Touch } from "../../theme";

// ── 상수 ──
const CARD_ADVANCE_THRESHOLD_M = 20; // 도착 지점 도달 판정 (목적지 전용)
const NEAR_POINT_FOR_PASS_M = 50; // 통과 감지 범위 (이탈 50m와 짝)
const DISTANCE_INCREASE_TOLERANCE_M = 6; // 최소 거리에서 이만큼 멀어지면 통과
const OFF_ROUTE_THRESHOLD_M = 50; // 경로 이탈 거리
const OFF_ROUTE_REROUTE_DEBOUNCE_MS = 3000; // 3초 지속 시 재탐색
const GPS_ACCURACY_THRESHOLD_M = 100;
const GPS_INTERVAL_MS = 2000;
const GPS_DISTANCE_FILTER_M = 3;
const ANNOUNCE_PREVIEW_M = 50; // 이만큼 다가오면 "잠시 후 …" 예고
const ANNOUNCE_ACT_M = 15; // 코앞 — "…하세요" 실행 안내 (필요하면 20까지 올려도 됨)
const MAP_ZOOM = 17;
const CAMERA_DURATION_MS = 300;
const ARRIVAL_END_DELAY_MS = 3000;

interface Props {
  tmapResponse: TmapResponse;
  onNavigationEnd?: () => void;
  onReroute?: (current: { latitude: number; longitude: number }) => void;
}

export default function NavigationScreen({
  tmapResponse,
  onNavigationEnd,
  onReroute,
}: Props) {
  const insets = useSafeAreaInsets();
  const [route, setRoute] = useState<NavigationRoute | null>(null);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [currentLocation, setCurrentLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [currentHeading, setCurrentHeading] = useState<number>(0);
  const [distanceToNext, setDistanceToNext] = useState(0);
  const [isOffRoute, setIsOffRoute] = useState(false);

  const cardIndexRef = useRef(0);
  const routeRef = useRef<NavigationRoute | null>(null);
  const onNavigationEndRef = useRef(onNavigationEnd);
  const onRerouteRef = useRef(onReroute);
  const locationSubRef = useRef<Location.LocationSubscription | null>(null);
  const mapRef = useRef<any>(null);
  const minDistRef = useRef<number>(Infinity);
  const offRouteSinceRef = useRef<number | null>(null);
  const previewSpokenRef = useRef(false);
  const actSpokenRef = useRef(false);

  useEffect(() => {
    onNavigationEndRef.current = onNavigationEnd;
    onRerouteRef.current = onReroute;
  }, [onNavigationEnd, onReroute]);

  // ── Tmap 응답 파싱 (재탐색 시에도 호출됨) ──
  useEffect(() => {
    const parsed = parseTmapResponse(tmapResponse);
    routeRef.current = parsed;
    setRoute(parsed);
    cardIndexRef.current = 0;
    setCurrentCardIndex(0);
    minDistRef.current = Infinity;
    offRouteSinceRef.current = null;
    setIsOffRoute(false);

    previewSpokenRef.current = true;
    actSpokenRef.current = true;
    if (parsed.cards.length > 0) {
      speakCard(parsed.cards[0]);
    }
  }, [tmapResponse]);

  // ── GPS 실시간 추적 ──
  useEffect(() => {
    let isMounted = true;

    async function startGpsTracking() {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") {
        // 권한 없으면 길안내 자체 불가 → 화면 종료
        onNavigationEndRef.current?.();
        return;
      }

      const subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: GPS_INTERVAL_MS,
          distanceInterval: GPS_DISTANCE_FILTER_M,
        },
        (location) => {
          if (!isMounted) return;
          handleLocationUpdate(location.coords);
        },
      );

      locationSubRef.current = subscription;
    }

    startGpsTracking();
    return () => {
      isMounted = false;
      locationSubRef.current?.remove();
      ttsStop();
    };
  }, []);

  // ── GPS 업데이트 → 카메라 추적 + 카드 전환 + 경로 이탈 ──
  const handleLocationUpdate = useCallback(
    (coords: {
      latitude: number;
      longitude: number;
      accuracy: number | null;
      heading: number | null;
    }) => {
      // 1. GPS 정확도 필터링
      if (
        coords.accuracy != null &&
        coords.accuracy > GPS_ACCURACY_THRESHOLD_M
      ) {
        return;
      }

      const r = routeRef.current;
      if (!r || r.cards.length === 0) return;

      const { latitude, longitude } = coords;
      setCurrentLocation({ latitude, longitude });

      // heading: -1이면 정지/측정 불가 → 이전 값 유지
      if (coords.heading != null && coords.heading >= 0) {
        setCurrentHeading(coords.heading);
      }

      // 카메라 추적 (위치 + 진행방향 위로)
      mapRef.current?.animateCameraTo({
        latitude,
        longitude,
        zoom: MAP_ZOOM,
        bearing: currentHeading,
        duration: CAMERA_DURATION_MS,
      });

      const cards = r.cards;
      const idx = cardIndexRef.current;
      if (idx >= cards.length) return;

      // 지금 다가가는 안내 지점 = 현재 카드의 지점
      const currentCard = cards[idx];

      const dist = haversine(
        latitude,
        longitude,
        currentCard.point.latitude,
        currentCard.point.longitude,
      );
      setDistanceToNext(dist);

      // 지점까지 가장 가까웠던 거리 기록 (통과 판정 기준점)
      if (dist < minDistRef.current) minDistRef.current = dist;

      // 2. 음성 안내 — 회전 지점에 다가오는 거리에 따라 단계별 (화면 안 봐도 귀로 따라가게)
      announceByDistance(currentCard, dist);

      // 3. 카드 전환 판정
      //    일반 안내: 지점에 가장 가까워졌다가 멀어지면 "통과"로 보고 전환 (표준 내비 방식)
      //    도착 지점: 반경 안에 들어오면 도착으로 보고 종료
      const arrived = dist < CARD_ADVANCE_THRESHOLD_M;
      const passed =
        minDistRef.current < NEAR_POINT_FOR_PASS_M &&
        dist > minDistRef.current + DISTANCE_INCREASE_TOLERANCE_M;

      if (currentCard.pointType === "end") {
        if (arrived) {
          cardIndexRef.current = cards.length; // 이후 업데이트 무시
          setTimeout(
            () => onNavigationEndRef.current?.(),
            ARRIVAL_END_DELAY_MS,
          );
        }
      } else if (passed && idx + 1 < cards.length) {
        const nextIdx = idx + 1;
        cardIndexRef.current = nextIdx;
        setCurrentCardIndex(nextIdx);
        minDistRef.current = Infinity;
        previewSpokenRef.current = false; // 다음 카드 안내 단계 초기화
        actSpokenRef.current = false;
      }

      // 3. 경로 이탈 감지 + 디바운스 재탐색
      //    지금 걷는 구간 = 다가가는 지점(idx)으로 들어오는 구간 = cards[idx-1]
      const walkedCard = idx > 0 ? cards[idx - 1] : currentCard;
      if (walkedCard.pathCoords.length > 0) {
        const pathDist = distanceToPath(
          latitude,
          longitude,
          walkedCard.pathCoords,
        );
        const off = pathDist > OFF_ROUTE_THRESHOLD_M;

        if (off) {
          setIsOffRoute(true);
          if (offRouteSinceRef.current === null) {
            offRouteSinceRef.current = Date.now();
          } else if (
            Date.now() - offRouteSinceRef.current >
            OFF_ROUTE_REROUTE_DEBOUNCE_MS
          ) {
            offRouteSinceRef.current = null;
            onRerouteRef.current?.({ latitude, longitude });
          }
        } else {
          setIsOffRoute(false);
          offRouteSinceRef.current = null;
        }
      }
    },
    [],
  );

  function speakCard(card: NavigationCard) {
    ttsSpeak(card.speech || card.actionLabel);
  }

  // 회전 지점까지 남은 거리에 따라 음성을 단계로 나눠 안내. 각 단계는 카드당 1회.
  function announceByDistance(card: NavigationCard, dist: number) {
    if (!actSpokenRef.current && dist <= ANNOUNCE_ACT_M) {
      actSpokenRef.current = true;
      previewSpokenRef.current = true; // 예고는 건너뜀
      ttsSpeak(card.speech || card.actionLabel);
      return;
    }
    if (!previewSpokenRef.current && dist <= ANNOUNCE_PREVIEW_M) {
      previewSpokenRef.current = true;
      const base = card.speech || card.actionLabel;
      // 도착 카드는 "잠시 후 곧 도착합니다"가 어색하므로 그대로 읽음.
      ttsSpeak(card.pointType === "end" ? base : `잠시 후 ${base}`);
    }
  }

  function handleReplay() {
    if (!route) return;
    speakCard(route.cards[currentCardIndex]);
  }

  function handleClose() {
    ttsStop();
    locationSubRef.current?.remove();
    onNavigationEndRef.current?.();
  }

  function getPassedCoords(): { latitude: number; longitude: number }[] {
    if (!route || !currentLocation) return [];
    return passedCoordsUpTo(
      currentLocation.latitude,
      currentLocation.longitude,
      route.fullPath,
    );
  }

  if (!route) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>경로를 준비하고 있어요</Text>
      </View>
    );
  }

  if (route.cards.length === 0) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>경로 정보를 받을 수 없어요</Text>
      </View>
    );
  }

  const currentCard = route.cards[currentCardIndex];
  const nextCard =
    currentCardIndex + 1 < route.cards.length
      ? route.cards[currentCardIndex + 1]
      : null;
  const passedCoords = getPassedCoords();

  // 도착 예상 시각 ("오후 1시 32분 도착")
  const arrivalDate = new Date(Date.now() + route.totalDuration * 1000);
  const ah = arrivalDate.getHours();
  const am = arrivalDate.getMinutes();
  const period = ah < 12 ? "오전" : "오후";
  const displayH = ah === 0 ? 12 : ah > 12 ? ah - 12 : ah;
  const arrivalText = `${period} ${displayH}시 ${am}분 도착`;

  return (
    <View style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="transparent"
        translucent
      />

      {/* ── 지도 풀스크린 ── */}
      <NaverMapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        initialCamera={{
          latitude: route.cards[0].point.latitude,
          longitude: route.cards[0].point.longitude,
          zoom: MAP_ZOOM,
        }}
        isShowLocationButton={false}
        isShowCompass={false}
        isShowScaleBar={false}
        isRotateGesturesEnabled={false}
        minZoom={14}
        maxZoom={19}
      >
        {/* 전체 경로 */}
        {route.fullPath.length > 1 && (
          <NaverMapPolylineOverlay
            coords={route.fullPath}
            color={Colors.brand.primary}
            width={10}
          />
        )}
        {/* 지나간 구간 */}
        {passedCoords.length > 1 && (
          <NaverMapPolylineOverlay
            coords={passedCoords}
            color={Colors.gray[400]}
            width={10}
          />
        )}
        {/* 안내지점 마커 */}
        {route.cards.filter(shouldShowMarker).map((card) => (
          <NaverMapMarkerOverlay
            key={`point-${card.index}`}
            latitude={card.point.latitude}
            longitude={card.point.longitude}
            image={{ symbol: "gray" }}
            width={32}
            height={42}
            anchor={{ x: 0.5, y: 1 }}
          />
        ))}
        {/* 현재 위치 — 진행방향 화살표 */}
        {currentLocation && (
          <NaverMapMarkerOverlay
            key="current-location"
            latitude={currentLocation.latitude}
            longitude={currentLocation.longitude}
            angle={0}
            width={48}
            height={48}
            anchor={{ x: 0.5, y: 0.5 }}
          >
            <View collapsable={false} style={styles.locationMarker}>
              <Text style={styles.locationMarkerArrow}>▲</Text>
            </View>
          </NaverMapMarkerOverlay>
        )}
      </NaverMapView>

      {/* ── 상단 오버레이: 안내 카드 + 도착 정보 ── */}
      <View
        style={[styles.topOverlay, { paddingTop: insets.top + Spacing.sm }]}
        pointerEvents="box-none"
      >
        <NavigationCardUI
          currentCard={currentCard}
          nextCard={nextCard}
          distanceToNext={distanceToNext}
        />

        <View style={styles.arrivalChip}>
          <Text style={styles.arrivalText}>
            {formatDistance(route.totalDistance)} ·{" "}
            {formatDuration(route.totalDuration)} · {arrivalText}
          </Text>
        </View>

        {isOffRoute && (
          <View style={styles.offRouteBanner}>
            <Text style={styles.offRouteText}>경로를 다시 찾고 있어요</Text>
          </View>
        )}
      </View>

      {/* ── 하단 오버레이: 버튼 ── */}
      <View
        style={[
          styles.bottomOverlay,
          { paddingBottom: insets.bottom + Spacing.sm },
        ]}
        pointerEvents="box-none"
      >
        <TouchableOpacity
          style={[styles.button, styles.replayButton]}
          onPress={handleReplay}
          activeOpacity={0.7}
        >
          <Text style={styles.replayText}>🔊 다시 듣기</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, styles.closeButton]}
          onPress={handleClose}
          activeOpacity={0.7}
        >
          <Text style={styles.closeText}>안내 종료</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface.background,
  },
  loading: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.surface.background,
  },
  loadingText: {
    fontSize: 18,
    color: Colors.text.secondary,
    letterSpacing: 0.2,
  },

  // 사용자 위치 마커
  locationMarker: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.semantic.warning,
    borderWidth: 4,
    borderColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    elevation: 8,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  locationMarkerArrow: {
    fontSize: 18,
    color: "#FFFFFF",
    fontWeight: "900",
    lineHeight: 20,
  },

  // 상단 오버레이
  topOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    paddingHorizontal: Spacing.md,
    gap: Spacing.xs,
  },
  arrivalChip: {
    alignSelf: "center",
    backgroundColor: Colors.surface.card,
    borderRadius: 999,
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  arrivalText: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.text.primary,
    letterSpacing: 0.2,
  },
  offRouteBanner: {
    alignSelf: "center",
    backgroundColor: Colors.semantic.danger,
    borderRadius: Radius.md,
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
    elevation: 4,
  },
  offRouteText: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.text.inverse,
    letterSpacing: 0.2,
  },

  // 하단 오버레이
  bottomOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  button: {
    flex: 1,
    minHeight: Touch.senior,
    borderRadius: Radius.lg,
    justifyContent: "center",
    alignItems: "center",
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  replayButton: {
    backgroundColor: Colors.surface.card,
    borderWidth: 2,
    borderColor: Colors.brand.primary,
  },
  replayText: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.brand.primary,
    letterSpacing: 0.2,
  },
  closeButton: {
    backgroundColor: Colors.gray[700],
  },
  closeText: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.text.inverse,
    letterSpacing: 0.2,
  },
});
